# If you edit in this repoitory:
* Use two space indentation,
* Use strict mode for JavaScript:
  * write `"strict mode"` under `<script>`,
* Always close empty elements:
  * `<br>` should be written as `<br/>`,
* Never skip optional elements like `<!DOCTYPE html>`, and `<head>`,
* Nest elements properly:
  * Example: `<p>This is a very long sentence <b>depending on who you ask.</b></p>`,
* Use camelCase,
* Always check if the code works properly.
