# Test: ANEWED.
A small game, to play it download the code as a .zip and open it with a browser (preferrably modern). You can delete the .zip file to get rid of the game.
