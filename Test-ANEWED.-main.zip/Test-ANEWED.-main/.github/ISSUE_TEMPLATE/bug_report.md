---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**What is your problem:**
*What is not working in the game?*

**What device is it on:**
*A PC? What OS?*
