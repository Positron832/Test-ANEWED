---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**What you want:**
*What feature do you want?*

**Suggestions on how to add it:**
*With JavaScript? HTML? CSS? How?*
